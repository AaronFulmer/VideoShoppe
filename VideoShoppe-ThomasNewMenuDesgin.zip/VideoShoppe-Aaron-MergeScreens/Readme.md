# Video Shoppe - CS 340 Spring 2019

Video Shoppe App created using Android Studio by Thomas Sullivan, Aaron Fulmer, Christian Guelledge, and Julia Rollins.

# How to import

Extract the zip file.  
Open your Android Tool Kit  
File > Open > Navigate to the extracted folder and select it > Choose your window to open the application in  
Done.  
  
# Changelog

**v1.2.0 2/25/2019**
- Working main menu with Check In Screen added.

**v1.1.0 2/25/2019**
- Created a login screen that hides user's password and prints out the Username and Password entered to an alert on the bottom of the screen for testing and verification purposes.
- Added the ability to transfer between activities as well as working admin login credentials

**v1.0.0 2/12/2019**  
- Date of creation.  
- Implemented a database with the aforementioned columns under the table Movie Database. TESTING PURPOSES ONLY
