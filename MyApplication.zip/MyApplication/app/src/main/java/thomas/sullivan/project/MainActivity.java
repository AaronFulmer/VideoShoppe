package thomas.sullivan.project;

import android.app.AlertDialog;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper movieDatabase;
    EditText editTitle,editActors,editDirector,editDate,editRatings,editGenre;
    Button btnAddMovie;
    Button btnViewAll;
    Button btnDeleteMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        movieDatabase = new DatabaseHelper(this);

        editTitle = (EditText)findViewById(R.id.editText_Title);
        editActors = (EditText)findViewById(R.id.editText_Actors);
        editDirector = (EditText)findViewById(R.id.editText_Director);
        editDate = (EditText)findViewById(R.id.editText_Date);
        editRatings = (EditText)findViewById(R.id.editText_Ratings);
        editGenre = (EditText)findViewById(R.id.editText_Genre);
        btnAddMovie = (Button)findViewById(R.id.button_add);
        btnViewAll = (Button)findViewById(R.id.button_viewAll);
        btnDeleteMovie = (Button)findViewById(R.id.button_delete);
        addMovie();
        viewAll();
        deleteMovie();
    }

    public void addMovie()
    {
        btnAddMovie.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = movieDatabase.insertMovie(editTitle.getText().toString(),
                                editActors.getText().toString(),
                                editDirector.getText().toString(),
                                editDate.getText().toString(),
                                editRatings.getText().toString(),
                                editGenre.getText().toString() );

                        if(isInserted == true)
                        {
                            Toast.makeText(MainActivity.this, "Movie has been added.", Toast.LENGTH_LONG).show();
                        }
                        else
                        {
                            Toast.makeText(MainActivity.this, "Failed to add movie.", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        );
    }

    public void deleteMovie() {
        btnDeleteMovie.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Integer deletedRows = movieDatabase.deleteMovie(editTitle.getText().toString());
                        if(deletedRows > 0)
                            Toast.makeText(MainActivity.this,deletedRows + " movies deleted",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"No movies deleted",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void viewAll() {
        btnViewAll.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = movieDatabase.getAllData();
                        if(res.getCount() == 0) {
                            // show message
                            showMessage("Error","Nothing found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("ID :"+ res.getString(0)+"\n");
                            buffer.append("Title :"+ res.getString(1)+"\n");
                            buffer.append("Actors :"+ res.getString(2)+"\n");
                            buffer.append("Director :"+ res.getString(3)+"\n");
                            buffer.append("Release Date :"+ res.getString(4)+"\n");
                            buffer.append("Ratings :"+ res.getString(5)+"\n");
                            buffer.append("Genre :"+ res.getString(6)+"\n\n");
                        }

                        // Show all data
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }





}
