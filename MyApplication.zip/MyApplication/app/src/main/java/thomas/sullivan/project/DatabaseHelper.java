package thomas.sullivan.project;

import android.content.ContentValues;
import android.database.Cursor;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String MOVIE_DATABASE = "MovieDatabase.db";
    public static final String DVD_TABLE = "Movie_Inventory";
    public static final String ID = "ID";
    public static final String TITLE = "TITLE";
    public static final String ACTORS = "ACTORS";
    public static final String DIRECTOR = "DIRECTOR";
    public static final String RELEASE_DATE = "RELEASE_DATE";
    public static final String RATINGS = "RATINGS";
    public static final String GENRE = "GENRE";


    //Database Default Constructor
    public DatabaseHelper(Context context)
    {
        super(context, MOVIE_DATABASE, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE "+DVD_TABLE+" (ID INTEGER PRIMARY KEY AUTOINCREMENT, TITLE TEXT, ACTORS TEXT, DIRECTOR TEXT, RELEASE_DATE TEXT, RATINGS TEXT, GENRE TEXT )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS "+DVD_TABLE);
        onCreate(db);
    }

    public boolean insertMovie(String title, String actors, String director, String releaseDate, String ratings, String genre )
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TITLE, title);
        contentValues.put(ACTORS, actors);
        contentValues.put(DIRECTOR, director);
        contentValues.put(RELEASE_DATE, releaseDate);
        contentValues.put(RATINGS, ratings);
        contentValues.put(GENRE, genre);
        long result = db.insert(DVD_TABLE,null,contentValues);
        if(result == -1)
        {
            return false;
        }
        else {
            return true;
        }
    }

    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+DVD_TABLE,null);
        return res;
    }

    public boolean updateData(String title,String actors,String director,String date, String ratings, String genre) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(TITLE,title);
        contentValues.put(ACTORS,actors);
        contentValues.put(DIRECTOR,director);
        contentValues.put(RELEASE_DATE,date);
        contentValues.put(RATINGS,ratings);
        contentValues.put(GENRE,genre);
        db.update(DVD_TABLE, contentValues, "ID = ?",new String[] { title });
        return true;
    }

    public Integer deleteMovie (String title) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(DVD_TABLE, "ID = ?",new String[] {title});
    }

}
